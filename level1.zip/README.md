# 32nd Catalysts Coding Contest

My solutions for the [32nd Catalysts Coding Contest](https://codingcontest.org/) in November 2019, written in Python.

:goat: :goat: :goat:

## Challenges

- :x: **[Level 1](data/level1/Level1.pdf)** - *unfinished*

## Requirements

### Python >= 3.7

Package requirements are specified in the [requirements.txt](requirements.txt) file.

```
pip3 install -r requirements.txt
```
