def solve(data):
    return "Result"
